import sec_cython
flag = input('input your flag:')
m = sec_cython.encrypt(flag)
if m != 'wrong':
    m = [hex(x.value) for x in m]
    m = [int(x, 16) for x in m]
    if m != sec_cython.enc:
        print('Wrong!')
    else:
        print('Correct!')
else:
    print('something wrong!')
